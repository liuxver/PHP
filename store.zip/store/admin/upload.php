<html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=HZ-GB-2312" />
	</head>
	<body bgcolor="antiquewhite" leftmargin="0" topmargin="0">
		<form name="form1" method="post" action="upfile.php" enctype="multipart/form-data">
			<input type="hidden" name="act" value="upload" />
			<input type="hidden" name="filepath" value="images" />
			<table width="100%" border="2" cellspacing="0" bordercolorlight="red" bordercolordark="blue">
				<tr>
					<td>商品图片上传：
					<input type="file" name="file1" style="width: 68%;" class="tx1" value="" />
					<input type="submit" name="submit" value="提交" class="tx"/>
					</td>
				</tr>
			</table>
		</form>
	</body>
</html>