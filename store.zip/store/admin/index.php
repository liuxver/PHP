<frameset framespacing="1" border="2" bordercolor="black" frameborder="yes">
	<frameset cols="20%,*">
		<frame name="contents" target="main" src="left.php" scrolling="auto" frameborder="1" />
		<frame name="main" src="typelist.php" scrolling="auto" noresize="noresize" frameborder="1" />                   
                                                                                                                            <!--
                                                                                                                            	作者：1369058574@qq.com
                                                                                                                            	时间：2017-05-02
                                                                                                                            	描述：有可能出错
                                                                                                                            -->
                                                                                                                            
	</frameset>
	<noframes>
		<body>
			<p>sorry，您的浏览器不支持框架！！！</p>
		</body>
	</noframes>
</frameset>